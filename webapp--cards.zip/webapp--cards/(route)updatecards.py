@app.route('/updatecards/<int:card_number>', methods=['GET', 'POST'])
def updatecards(card_number):
    if 'email' not in session:
        flash(f'Please login first','danger')
        return redirect(url_for('login'))
    creditcard = creditcard.query.get_or_404(id)
    form = AddcardForm(request.form)
    if request.method == 'POST':
        creditcard = creditcard(
                    da_line_one= form.da_line_one.data, da_line_two = form.da_line_two.data,
                    da_city = form.da_city.data, da_state = form.da_state.data,
                    da_zipcode = form.da_zipcode.data)
        db.session.commit()
        flash(f'Your credit card info has been updated.','success')
        return redirect(url_for('customer'))
    form.da_line_one.data = creditcard.da_line_one
    form.da_line_two.data = creditcard.da_line_two
    form.da_city.data = creditcard.da_city
    form.da_state.data = creditcard.da_state
    form.da_zipcode.data = creditcard.da_zipcode
    return render_template('customer/updatecards.html', title = "Update Credit Cards", form = form, creditcard=creditcard)