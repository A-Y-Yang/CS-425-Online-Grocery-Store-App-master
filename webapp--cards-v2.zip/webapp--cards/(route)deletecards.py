@app.route('/deletecards/<int:card_number>', methods=["POST"])
def deletecards(card_number):
    if 'email' not in session:
        flash(f'Please login first','danger')
        return redirect(url_for('login'))
    creditcard = creditcard.query.get_or_404(card_number)
    if request.method == "POST":
        try:
            os.unlink(os.path.join(current_app.root_path))
        except Exception as e:
            print(e)
        db.session.delete(creditcard)
        db.session.commit()
        flash(f'Your credit card {creditcard.card_number} was deleted.', 'success')
        return redirect(url_for('customer'))
    flash(f'Cannot delete the card.','danger')
    return render_template(url_for('customer'))