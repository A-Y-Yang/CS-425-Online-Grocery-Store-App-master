@app.route('/addcards', methods=['GET', 'POST'])
def addcards():
    if 'email' not in session:
        flash(f'Please login first','danger')
        return redirect(url_for('login'))
    form = AddcardForm(request.form)
    if request.method == 'POST':
        creditcard = CreditCard(card_number = form.card_number.data, card_owner_name = form.card_owner_name.data,
                    card_expire_date = form.card_expire_date.data, card_cvv = form.card_cvv.data, 
                    CBA_line_one = form.CBA_line_one.data, CBA_line_two = form.CBA_line_two.data, 
                    CBA_city = form.CBA_city.data, CBA_state = form.CBA_state.data, 
                    CBA_zipcode = form.CBA_zipcode.data)
        db.session.add(creditcard)
        db.session.commit()
        flash(f'A new credit card is added to your database.', 'success')
        return redirect(url_for('customer'))
    return render_template('customer/addcards.html', title = "Add Card Page", form = form, creditcard = creditcard)