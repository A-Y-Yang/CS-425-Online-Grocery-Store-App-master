@app.route('/creditcards')
def creditcards():
    if 'email' not in session:
        flash(f'Please login first','danger')
        return redirect(url_for('home'))
    creditcards = CreditCard.query.all()
    return render_template('admin/creditcards.html', title = 'Credit Card Page', creditcards = creditcards)